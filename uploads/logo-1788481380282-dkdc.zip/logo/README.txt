SkillsJewels logo — "Joint" direction
=====================================

The mark is a dovetail: two solid halves cut to fit each other, held apart by a
hairline gap so the join stays legible down to 16px. Sapphire is the tertiary
education side, Amethyst the employment services side.

FILES

svg/
  SkillsJewels_Mark.svg                        Two-colour mark (primary)
  SkillsJewels_Mark_Sapphire.svg               One-colour, Sapphire
  SkillsJewels_Mark_Reversed.svg               Chalk, for Sapphire/Amethyst grounds
  SkillsJewels_Mark_Currentcolor.svg           Inherits CSS colour — for web/app use
  SkillsJewels_Lockup_Horizontal.svg           Mark + wordmark, two-colour
  SkillsJewels_Lockup_Horizontal_Sapphire.svg  One-colour
  SkillsJewels_Lockup_Horizontal_Reversed.svg  Reversed
  SkillsJewels_Lockup_Stacked.svg              Centred, with tagline
  SkillsJewels_Lockup_Stacked_NoTagline.svg    Centred, mark + wordmark only
  SkillsJewels_Lockup_Stacked_Reversed.svg     Centred, with tagline, reversed

png/
  Mark rasters at 16, 32, 64, 128, 256, 512, 1024 px (transparent background),
  plus reversed 512 and one-colour Sapphire 512. Use for favicons, avatars and
  anywhere SVG is not accepted.

SPECIFICATION

  Mark artwork      76 x 76 units, square. Gap between halves: 4 units.
  Colours           Sapphire  #1B3A5C
                    Amethyst  #5B3A73
                    Chalk     #F7F5F0  (reversed artwork)
  Wordmark          Public Sans SemiBold (600), two words: "Skills Jewels".
                    Skills in Sapphire, Jewels in Amethyst.
                    Fallback: Arial Bold.
  Tagline           Public Sans Regular, letter-spacing +0.04em, Sapphire.
                    "Driving skills and tertiary qualifications for employment services"
  Minimum sizes     Full lockup 25mm wide. Mark alone 8mm / 16px wide.
  Clear space       Equal to the width of the gap x 4 (16 units) on all sides.

NOTES

  The wordmark in the lockup SVGs is live text set in Public Sans. It renders
  correctly wherever Public Sans is installed or webfont-loaded. For print
  artwork and third-party handoff, open the SVG in a vector editor and convert
  the text to outlines first.

  Do not stretch, rotate, recolour or add effects. Do not close the gap between
  the two halves, and do not use one half on its own.
